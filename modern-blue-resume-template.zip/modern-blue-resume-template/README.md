# Modern Blue One-page LaTeX Resume Template

A compact, one-page LaTeX resume template designed for technical internships and engineering roles.

## Features

- One-page A4 layout
- XeLaTeX support
- Modern blue-accent section style
- Three-line, two-column header information block
- Optional portrait photo slot
- ATS-friendly PDF bookmarks via `bookmark` and `hyperref`
- Skill tag pills using `tcolorbox`
- Chinese / English font fallback for Overleaf

## Files

```text
.
├── main.tex
├── README.md
└── photo.jpg          # optional; not included by default
```

## How to use

1. Upload `main.tex` to Overleaf.
2. Set compiler to **XeLaTeX**.
3. Replace placeholder fields:
   - `YOUR NAME`
   - email / phone / GitHub / location
   - education, projects, research, skills
4. Optional: upload your portrait image as `photo.jpg`.
5. Recompile.

## Local compile

```bash
xelatex main.tex
```

Run twice if PDF bookmarks do not refresh.

## Notes

- Keep the resume to one page by shortening bullets before reducing font size.
- For ATS-heavy applications, consider creating a second plain-text version without icons and tag boxes.
- The template uses public fonts when available: Inter / IBM Plex Sans / Noto Sans CJK SC / Source Han Sans SC, with fallback to Fandol on Overleaf.

## License

MIT License. You can use, modify, and publish it freely.
